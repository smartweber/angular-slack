export const appConfig = {
    apiUrl: 'http://localhost:3000'
};